self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "66c3f2b51793f701bbf77503c80be9aa",
    "url": "./0dccc3ba35984f8aecaf.worker.js"
  },
  {
    "revision": "455f9f3ae849b1b7c9d5b5f2d351830a",
    "url": "./0dccc3ba35984f8aecaf.worker.js.LICENSE"
  },
  {
    "revision": "918726445b2f8f14baddeeb3c2a0bc35",
    "url": "./4d9b735f86396051a725.worker.js"
  },
  {
    "revision": "455f9f3ae849b1b7c9d5b5f2d351830a",
    "url": "./4d9b735f86396051a725.worker.js.LICENSE"
  },
  {
    "revision": "c3ebdd5729511c7cc7cdc1ff6728a44b",
    "url": "./index.html"
  },
  {
    "revision": "006957a27ef8a2a69b12",
    "url": "./static/css/2.8c2ad249.chunk.css"
  },
  {
    "revision": "a37d9505ae4ac8e1d718",
    "url": "./static/css/main.a0ca3105.chunk.css"
  },
  {
    "revision": "006957a27ef8a2a69b12",
    "url": "./static/js/2.ebc708b1.chunk.js"
  },
  {
    "revision": "a647d94582c0cb694bd79d703ea6fdf2",
    "url": "./static/js/2.ebc708b1.chunk.js.LICENSE"
  },
  {
    "revision": "a37d9505ae4ac8e1d718",
    "url": "./static/js/main.5077465d.chunk.js"
  },
  {
    "revision": "4bafa228a61f2396a441e507473e8cf9",
    "url": "./static/js/main.5077465d.chunk.js.LICENSE"
  },
  {
    "revision": "20830a0b5e9a4fc66c98",
    "url": "./static/js/runtime-main.de37e33f.js"
  },
  {
    "revision": "06d100cbc80aa1ed3a7643005794fda7",
    "url": "./static/media/NotoSans-Regular.06d100cb.eot"
  },
  {
    "revision": "aa283550181a649994822d16dd2d8e91",
    "url": "./static/media/NotoSans-Regular.aa283550.woff2"
  },
  {
    "revision": "edbefd4189c1916795792fcfa9c08e11",
    "url": "./static/media/NotoSans-Regular.edbefd41.ttf"
  },
  {
    "revision": "fbe46f26a3381739983bef1da5c94fbd",
    "url": "./static/media/NotoSans-Regular.fbe46f26.woff"
  },
  {
    "revision": "b97f0e19669824b471f69e6064dcb10c",
    "url": "./static/media/donation.b97f0e19.png"
  },
  {
    "revision": "088a34f78f530102fd9661173b4a4f26",
    "url": "./static/media/fa-brands-400.088a34f7.eot"
  },
  {
    "revision": "273dc9bf9778fd37fa61357645d46a28",
    "url": "./static/media/fa-brands-400.273dc9bf.ttf"
  },
  {
    "revision": "822d94f19fe57477865209e1242a3c63",
    "url": "./static/media/fa-brands-400.822d94f1.woff2"
  },
  {
    "revision": "d72293118cda50ec50c39957d9d836d0",
    "url": "./static/media/fa-brands-400.d7229311.svg"
  },
  {
    "revision": "f4920c94c0861c537f72ba36590f6362",
    "url": "./static/media/fa-brands-400.f4920c94.woff"
  },
  {
    "revision": "3ac49cb33f43a6471f21ab3df40d1b1e",
    "url": "./static/media/fa-regular-400.3ac49cb3.eot"
  },
  {
    "revision": "9efb86976bd53e159166c12365f61e25",
    "url": "./static/media/fa-regular-400.9efb8697.woff2"
  },
  {
    "revision": "a57bcf76c178aee452db7a57b75509b6",
    "url": "./static/media/fa-regular-400.a57bcf76.woff"
  },
  {
    "revision": "d2e53334c22a9a4937bc26e84b36e1e0",
    "url": "./static/media/fa-regular-400.d2e53334.svg"
  },
  {
    "revision": "ece54318791c51b52dfdc689efdb6271",
    "url": "./static/media/fa-regular-400.ece54318.ttf"
  },
  {
    "revision": "2aa6edf8f296a43b32df35f330b7c81c",
    "url": "./static/media/fa-solid-900.2aa6edf8.ttf"
  },
  {
    "revision": "7a5de9b08012e4da40504f2cf126a351",
    "url": "./static/media/fa-solid-900.7a5de9b0.svg"
  },
  {
    "revision": "7fb1cdd9c3b889161216a13267b55fe2",
    "url": "./static/media/fa-solid-900.7fb1cdd9.eot"
  },
  {
    "revision": "93f284548b42ab76fe3fd03a9d3a2180",
    "url": "./static/media/fa-solid-900.93f28454.woff"
  },
  {
    "revision": "f6121be597a72928f54e7ab5b95512a1",
    "url": "./static/media/fa-solid-900.f6121be5.woff2"
  },
  {
    "revision": "fafb30c0d4050629d76ed1f9efe6d911",
    "url": "./static/media/logo.fafb30c0.png"
  },
  {
    "revision": "0ae84ba6d90b8dc8067ce7c470355196",
    "url": "./static/media/modal-bg.0ae84ba6.png"
  },
  {
    "revision": "ab6ebbf491a783a7a0b6e300071cc9f5",
    "url": "./static/media/nano.ab6ebbf4.svg"
  }
]);